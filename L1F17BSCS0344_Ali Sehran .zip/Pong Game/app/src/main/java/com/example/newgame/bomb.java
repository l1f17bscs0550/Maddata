package com.example.newgame;

import android.graphics.RectF;

public class bomb {
    private RectF rect;
    private float yVelocity;
    private float Width = 25;
    private float Height = 25;
    private boolean visibilty;
    int screenEnd;
    public bomb(int x,int y,int screenY) {
        rect=new RectF(x,y,x+Width,y+Height);
        yVelocity=200;
        visibilty=true;
        screenEnd=screenY;
    }

    public boolean isVisibilty() {
        return visibilty;
    }

    void update(long fps) {
        if(visibilty) {
            rect.top = rect.top + (yVelocity / fps);
            rect.bottom = rect.top + Height;
            if (rect.bottom >= screenEnd) {
                visibilty=false;
            }
        }
    }

    public void setVisibilty(boolean visibilty) {
        this.visibilty = visibilty;
    }

    public RectF getRect() {
        return rect;
    }
}
