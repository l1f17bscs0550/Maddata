package com.example.newgame;

import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import java.util.Random;

public class Ball {

    private RectF rect;
    private float xVelocity;
    private float yVelocity;
    private float ballWidth = 15;
    private float ballHeight = 15;

    Ball() {

        xVelocity = 200;
        yVelocity = -400;
        rect = new RectF();
    }

    void update(long fps) {
        rect.left = rect.left + (xVelocity / fps);
        rect.top = rect.top + (yVelocity / fps);
        rect.right = rect.left + ballWidth;
        rect.bottom = rect.top + ballHeight;
    }

    void reset(int screenX, int screenY) {
        rect.left=screenX/2;
        rect.top=screenY-100;
        rect.right=screenX/2+ballWidth;
        rect.bottom=(screenY-100) + ballHeight;
    }

    public RectF getRect() {
        return rect;
    }
    void reverseXVelocity()
    {
        xVelocity=- xVelocity;
    }
    void reverseYVelocity()
    {
        yVelocity=- yVelocity;
    }
    void setRandomXVelocity()
    {
        Random genrator=new Random();
        int answer=genrator.nextInt(2);
        if(answer==0)
        {
            reverseXVelocity();
        }
    }




}
