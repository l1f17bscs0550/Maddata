package com.example.newgame;

import android.graphics.RectF;
import android.util.Log;

public class Bat {
    private RectF rect;
    private float length;
    private float x;
    private float batSpeed;

    final int STOPPED = 0;
    final int LEFT = 1;
    final int RIGHT = 2;
    private int batMoving = STOPPED;
    private int ScreenX,ScreenY;
    Bat(int screenX, int screenY){
        ScreenX=screenX;
        ScreenY=screenY;
        length = 130;
        float height = 40;
        x = screenX / 2;
        float y = screenY - 40;
        rect = new RectF(x, y, x + length, y + height);
        batSpeed = 350;
    }

    RectF getRect(){

        return rect;
    }

    void setMovementState(int state){
        batMoving = state;

    }
    void reset()
    {
        rect.left=ScreenX/2;
        rect.right=ScreenX/2+length;
        batMoving = STOPPED;
        lengthDefault();

    }
    void lengthDefault()
    {
        length=130;
    }

    void increaseLength()
    {
        length=length+((20*length)/100);
    }

    void update(long fps){
        if(batMoving == LEFT && rect.left>0){

            x = x - batSpeed / fps;
        }

        if(batMoving == RIGHT &&rect.right<ScreenX){

            x = x + batSpeed / fps;
        }

        rect.left = x;
        rect.right = x + length;
    }
}








