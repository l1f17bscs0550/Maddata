package com.example.newgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class PongEngine extends SurfaceView implements Runnable{

    private RectF LeftBtn;
    private RectF RightBtn;

    public Thread gameThread = null;
    public SurfaceHolder ourHolder;
    public volatile boolean playing;
    public boolean paused = true;

    public Canvas canvas;
    public Paint paint;
    Paint ballPaint;
    private int screenX;
    private int screenY;

    private long fps;
    private long timeThisFrame;

    int lives = 3;
    int score = 0;

    Bat bat;
    Ball ball;
    Block [] blocks = new Block[200];
    int numBlocks;

    int bombNumber;
    bomb[] bombs=new bomb[4];

    int powerUpNumber;
    powerUp[] powerUps=new powerUp[4];

    private boolean isWin;
    private boolean isLoss;

    private String BallColor;

    public PongEngine(Context context, int x, int y) {
        super(context);
        LeftBtn=new RectF(0,y,200,y+150);
        RightBtn=new RectF(x-200,y,x,y+150);

        ourHolder = getHolder();
        paint = new Paint();
        ballPaint=new Paint();
        screenX = x;
        screenY = y;
        ballPaint.setColor(Color.argb(255, 200, 50, 50));
        bat = new Bat(screenX, screenY);
        ball=new Ball();
        setGame();
    }
    //Block Details
    public void setGame()
    {
        Log.i("PONG","SET GAME CALLED");
        bat.reset();
        ball.reset(screenX,screenY);
        isLoss=isWin=false;
        bombNumber=0;
        powerUpNumber=0;
        int brickWidth=screenX/10;
        int brickHeight=screenY/13;
        numBlocks=0;
        String Colr;
        for(int column=0;column<10;column++)
        {
            for(int row=0;row<3;row++)
            {
                if((column==2||column==7) &&(row==0||row==2))
                {
                    Colr="Green";
                }
                else if((column==4||column==5) &&(row==0||row==2))
                {
                    Colr="Red";
                }
                else
                {
                    Colr="Sky";
                }
                blocks[numBlocks]=new Block(row,column,brickWidth,brickHeight,Colr);
                numBlocks++;
            }
        }
        int Mult=7;
        int MultR;
        for(int col=0;col<3;col++)
        {
            MultR=8;
            for(int row=0;row<3;row++)
            {
                Colr="Orange";
                blocks[numBlocks]=new Block(row+MultR,col+Mult,brickWidth/2,brickHeight/2,Colr);
                MultR++;
                numBlocks++;

            }
            Mult+=2;

        }
        score=0;
        lives=3;
    }

    @Override
    public void run() {

        Log.i("PONG","RUN CALLED");
        while (playing) {

            if (!paused) {
                update();
            }

            draw();
        }
    }

    public void pause() {

        Log.i("PONG","PAUSE CALLED");
        playing = false;
        try {
            gameThread.join();
        }
        catch (InterruptedException e) {
            Log.e("Error", "joining thread");
        }
    }

    public void resume() {

        Log.i("PONG","RESUME CALLED");
        playing = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void update() {
        bat.update(60);
        ball.update(60);
        for(int i=0;i<bombNumber;i++)
        {
            if(bombs[i].isVisibilty())
            {
                if(RectF.intersects(bombs[i].getRect(),bat.getRect()))
                {
                    bombs[i].setVisibilty(false);
                    score=0;
                }
                bombs[i].update(60);
            }
        }
        for(int i=0;i<powerUpNumber;i++)
        {
            if(powerUps[i].isVisibilty())
            {
                if(RectF.intersects(powerUps[i].getRect(),bat.getRect()))
                {
                    powerUps[i].setVisibilty(false);
                    bat.increaseLength();

                }
                powerUps[i].update(60);
            }
        }

        for (int i=0;i<numBlocks;i++)
        {
            if(blocks[i].getVisiblity())
            {

                if(blocks[i].getRect().intersect(ball.getRect()))
                {
                    BallColor=blocks[i].getColor();
                    blocks[i].setInvisiblity();
                    ball.reverseYVelocity();
                    if(blocks[i].getColor().equals("Sky"))
                    {
                        score=score+10;
                    }
                    if(blocks[i].getColor().equals("Orange"))
                    {
                        score+=5;
                    }
                    if(blocks[i].getColor().equals("Red"))
                    {
                        bombs[bombNumber++]=new bomb((int)blocks[i].getRect().centerX(),(int)blocks[i].getRect().centerY(),screenY);
                    }
                    if(blocks[i].getColor().equals("Green"))
                    {
                        powerUps[powerUpNumber++]=new powerUp((int)blocks[i].getRect().centerX(),(int)blocks[i].getRect().centerY(),screenY);
                    }
                }

            }
        }
        if(RectF.intersects(ball.getRect(),bat.getRect()))
        {
            ball.reverseYVelocity();
            ball.setRandomXVelocity();
        }
        if (ball.getRect().right>=screenX)
        {
            ball.reverseXVelocity();
        }
        if(ball.getRect().left<=0)
        {
            ball.reverseXVelocity();
        }
        if(ball.getRect().top<=0)
        {
            ball.reverseYVelocity();
        }
        if(ball.getRect().bottom>=screenY)
        {
            ball.reverseYVelocity();
            lives--;
            if(lives==0)
            {

                setGame();
                Lose();
            }
        }
        if(score>=240)
        {
            setGame();
            Win();
        }

    }

    public void draw () {

        Log.i("PONG","DRAW CALLED");
        if (ourHolder.getSurface().isValid()) {
            canvas = ourHolder.lockCanvas();

            canvas.drawColor(Color.argb(255, 255, 255, 255));
            paint.setColor(Color.argb(255, 200, 50, 50));
            canvas.drawRect(bat.getRect(), paint);
            //canvas.drawRect(ball.getRect(), paint);
            int ballCenterX=(int)ball.getRect().centerX();
            int ballCenterY=(int)ball.getRect().centerY();

            if(BallColor!=null && BallColor.equals("Sky"))
            {
                ballPaint.setColor(Color.argb(255, 0, 255, 255));
            }
            else if(BallColor!=null &&BallColor.equals("Green"))
            {
                ballPaint.setColor(Color.argb(255, 0, 153, 0));
            }
            else if(BallColor!=null &&BallColor.equals("Red"))
            {
                ballPaint.setColor(Color.argb(255, 153, 0, 0));
            }
            else if(BallColor!=null &&BallColor.equals("Orange"))
            {
                ballPaint.setColor(Color.argb(255,200,100,100));
            }
            else
            {
                BallColor="Default";
            }

            canvas.drawCircle(ballCenterX,ballCenterY,15,ballPaint);

            for(int i=0;i<numBlocks;i++)
            {
                if(blocks[i].getVisiblity())
                {
                    if(blocks[i].getColor().equals("Sky"))
                    {
                        paint.setColor(Color.argb(255, 0, 255, 255));
                    }
                    else if(blocks[i].getColor().equals("Green"))
                    {
                        paint.setColor(Color.argb(255, 0, 153, 0));
                    }
                    else if(blocks[i].getColor().equals("Red"))
                    {
                        paint.setColor(Color.argb(255, 153, 0, 0));
                    }
                    else
                    {
                        paint.setColor(Color.argb(255,200,100,100));
                    }
                    canvas.drawRect(blocks[i].getRect(),paint);
                }
            }
            if(isLoss)
            {
                paint.setTextSize(100);

                paint.setColor(Color.argb(255, 192, 0, 192));
                canvas.drawText("You Lose", screenX / 2 -200, screenY/2+100, paint);

            }
            if(isWin)
            {
                paint.setTextSize(100);

                paint.setColor(Color.argb(255, 192, 0, 192));
                canvas.drawText("You WON", screenX / 2 -200 , screenY/2+100, paint);
            }

            paint.setColor(Color.argb(255, 192, 192, 192));
            canvas.drawRect(0,screenX-150,screenX,screenY,paint);
            paint.setColor(Color.argb(255, 0, 0, 0));
            paint.setTextSize(70);

            canvas.drawText("Score : "+score+"         "+BallColor+"         "+"Lives : "+lives,screenX/2-480,screenY+100,paint);


            paint.setColor(Color.argb(255,242,242,242));
            canvas.drawRect(LeftBtn,paint);
            canvas.drawRect(RightBtn,paint);
            paint.setColor(Color.BLACK);
            for(int i=0;i<bombNumber;i++)
            {
                if(bombs[i].isVisibilty())
                {
                    canvas.drawRect(bombs[i].getRect(),paint);
                }
            }
            paint.setTextSize(50);
            canvas.drawText("Left",LeftBtn.centerX()-35,LeftBtn.centerY(),paint);
            canvas.drawText("Right",RightBtn.centerX()-45,RightBtn.centerY(),paint);
            paint.setColor(Color.GREEN);

            for(int i=0;i<powerUpNumber;i++)
            {
                if(powerUps[i].isVisibilty())
                {
                    canvas.drawRect(powerUps[i].getRect(),paint);
                }
            }

            ourHolder.unlockCanvasAndPost(canvas);
        }

    }
    void Lose()
    {
        isLoss=true;
        paused=true;
    }
    void Win()
    {
        isWin=true;
        paused=true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {

        if(paused==true &&(isWin==true || isLoss==true))
        {
            isWin=isLoss=false;
        }

        switch(motionEvent.getAction() & MotionEvent.ACTION_MASK) {

            case MotionEvent.ACTION_DOWN:
                paused = false;
                //if(motionEvent.getX()>screenX/2)
                if(RightBtn.contains(motionEvent.getX(),motionEvent.getY()))
                {
                    bat.setMovementState(bat.RIGHT);
                }
                else if(LeftBtn.contains(motionEvent.getX(),motionEvent.getY())) {
                    bat.setMovementState(bat.LEFT);
                }
                break;

            case MotionEvent.ACTION_UP:
                bat.setMovementState(bat.STOPPED);
                break;
        }
        return true;
    }
}
