package com.example.newgame;

import android.graphics.RectF;

public class Block {
    private RectF rect;
    private boolean isVisible;

    private String Color;

    Block(int row, int column, int width, int height, String Colr) {
        isVisible = true;
        Color = Colr;
        int padding = 2;
        rect = new RectF(column * width + padding, row * height + padding, column * width + width - padding, row * height + height - padding);
    }

    public String getColor() {
        return Color;
    }

    public RectF getRect() {
        return rect;
    }

    public boolean getVisiblity() {
        return isVisible;
    }

    public void setInvisiblity() {
        isVisible = false;
    }

    void setRect(RectF rect) {
        this.rect = rect;
    }
}
