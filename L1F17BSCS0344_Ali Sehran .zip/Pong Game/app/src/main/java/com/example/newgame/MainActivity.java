package com.example.newgame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;

public class MainActivity extends Activity {

    PongEngine pongEngine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Display display = getWindowManager().getDefaultDisplay();

        Point size = new Point();
        display.getSize(size);

        pongEngine = new PongEngine(this, size.x, size.y-150);
        setContentView(pongEngine);

    }

    @Override
    protected void onPause() {

        super.onPause();

        Log.i("PONG","ON PAUSE CALLED");
        pongEngine.pause();
    }

    @Override
    protected void onResume() {

        super.onResume();

        Log.i("PONG","ON RESUME CALLED");
        pongEngine.resume();
    }
}
